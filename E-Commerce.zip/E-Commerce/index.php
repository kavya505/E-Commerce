<?php header('Location: public/ver.html'); ?>
