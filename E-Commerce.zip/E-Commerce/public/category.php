<?php require_once("../resources/config.php"); ?>

<?php include(TEMPLATE_FRONT . DS . "header.php") ?>

<header></header>

<!-- Page Content -->
    <div class="container">

        <!-- Page Features -->
        <div class="row">
            
            <div class="col-lg-4">
            <?php include(TEMPLATE_FRONT . DS . "side_nav.php") ?>
            </div>
            
            <div class="col-lg-8">
              <div class="row">  
                        <? if (isset($_GET["page"])) {
                    $page = $_GET["page"];
                    }

                    else {
                            $page=1;
                    }
                ?>
              <?php get_products_in_cat_page($page); ?>
            </div> 

        </div>
        <!-- /.row -->

      

    </div>
    <!-- /.container -->


<?php include(TEMPLATE_FRONT . DS . "footer.php") ?>
