<?php require_once("../resources/config.php"); ?>

<?php include(TEMPLATE_FRONT . DS . "header.php") ?>


<body>
    <hr>
        <div class="container">
<div class="row">
        <div class="col-md-6" style="border-right: thick double lightgrey";>
            <form action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> method="post">
    <div class="form-group">
        <label for="inputName">Name</label>
        <input type="text" class="form-control" name="name" placeholder="Enter Your Name" required>
    </div>
    
     <div class="form-group">
        <label for="inputEmail">Email</label>
        <input type="email" class="form-control" name="email"  placeholder="Enter Your Email" required>
    </div>
                
     <div class="form-group">
        <label for="inputPhone">phone</label>
        <input type="text" class="form-control" name="phone" placeholder="Need Your Phone Number" required>
    </div>
    
    <div class="form-group">
        <label for="inputMessage">Message</label>
        <textarea class="form-control" name="message" rows="5"  placeholder="Enter Message Here." required></textarea>
    </div>
                <center><input type="submit" name="submit" value="Send" class="btn btn-primary"/>
  </form> 
 
<!-- inserting contact form -->            
<?php
 if (!empty($_POST)){
$host="naivestuff.com.mysql"; // Host name 
$username="naivestuff_com"; // Mysql username 
$password="test123"; // Mysql password 
$db_name="naivestuff_com"; // Database name 
$tbl_name="inbox"; // Table name 

// Connect to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// Get values from form 
$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$message=$_POST['message'];

// Insert data into mysql 
$sql="INSERT INTO $tbl_name(name, email, phone, message)VALUES('$name','$email','$phone','$message')";
$result=mysql_query($sql);

if($result){
echo "<h3><i class='label label-success'>Message Sent Successfully</i></h3>";
echo "<BR>";
}

else {
echo "ERROR";
}
mysql_close();
}
?> 
<!-- inserting contact form -->    
</center>
    </div> 
            <div class="col-md-6" style="text-align:left;">
        <address>
          <h3>Oiveiras</h3><br>
          <span id="map-input">
          1102 S Abel St.<br>
          Unit 306, CA 95035<br>
          </span>
          P: (123) 456-7890
         </address>
         <address>
          <strong>Email Us</strong><br>
          <a href="mailto:#">oliveiras@oliveiras.com</a>
         </address> 
        </div>
    </div>

        </div>
</body>
<?php include(TEMPLATE_FRONT . DS . "footer.php") ?>