<?php

$host="naivestuff.com.mysql"; // Host name 
$username="naivestuff_com"; // Mysql username 
$password="test123"; // Mysql password 
$db_name="naivestuff_com"; // Database name 
$tbl_name="reviews"; // Table name 

// Connect to server and select database.
$link=mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

//session_start();
$rpid = $_SESSION['rpid'];
$product_id=(int)($rpid);
   
// Insert data into mysql 
$sql="select * from reviews where product_id=$product_id";
     
$result=mysql_query($sql);

while($row = mysql_fetch_assoc($result)){
     echo "<p class='lead'>{$row['content']}</p> <p class='text-right'>by <i style='font-size:12px; color:blue'>{$row['u_name']}</i> &nbsp; </p> <br><hr>" ;
}
     //header("Location: item.php?id={$product_id}");
     mysql_close();
     
?> 