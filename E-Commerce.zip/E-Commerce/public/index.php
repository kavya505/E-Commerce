<?php require_once("../resources/config.php"); ?>

<?php include(TEMPLATE_FRONT . DS . "header.php") ?>

<div class="row carousel-holder">

                    <div class="col-md-12">

                      <?php include(TEMPLATE_FRONT . DS . "slider.php") ?>
                                          
                    </div>

                </div>
<?php //include(TEMPLATE_FRONT . DS . "side_nav.php") ?>
    <!-- Page Content -->
    <div class="container">
        
                <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-10">
                      <!-- Three columns of text below the carousel -->
      <div class="row">
          <center>
        <div id="box" class="col-lg-4 image-wrapper spini">
             <a href="category.php?id=34"><span class="image-overlay">
                 <span class="content"><h3>WINES</h3></span></span></a>
          <img src="../resources/uploads/wine_home_page.jpg" alt="Generic placeholder image" width="200" height="200">
        </div><!-- /.col-lg-4 -->
                  
        <div id="box" class="col-lg-4 image-wrapper spini">
           <a href="category.php?id=35"><span class="image-overlay">
                 <span class="content"><h3>LIQUOR</h3></span></span></a>
          <img  src="../resources/uploads/vodka_homepage.jpg" alt="Generic placeholder image" width="200" height="200">
               
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4 image-wrapper spini">
            <a href="category.php?id=36"><span class="image-overlay">
                 <span class="content"><h3>BEERS</h3></span></span></a>
          <img  src="../resources/uploads/beer_homepage.png" alt="Generic placeholder image" width="200" height="200">
        </div> </center><!-- /.col-lg-4 -->
      </div><!-- /.row -->
   
   <hr>
                <center><h3>OUR PRODUCTS</h3></center>
   <hr>
                
            </div>
            <div class="col-md-1"></div>
        </div>
        
        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-10">

                <div class="row">
                    <? if (isset($_GET["page"])) {
                    $page = $_GET["page"];
                    }

                    else {
                            $page=1;
                    }
                ?>
                    <?php get_products($page); ?>
                
            
            </div>
            <div class="col-md-1"></div>
        </div>

    </div>
<?php include(TEMPLATE_FRONT . DS . "footer.php") ?>
