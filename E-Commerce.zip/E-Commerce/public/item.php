<?php require_once("../resources/config.php"); ?>

<?php include(TEMPLATE_FRONT . DS . "header.php") ?>


<?php
 if (!empty($_POST['submit'])){
$host="naivestuff.com.mysql"; // Host name 
$username="naivestuff_com"; // Mysql username 
$password="test123"; // Mysql password 
$db_name="naivestuff_com"; // Database name 
$tbl_name="reviews"; // Table name 

// Connect to server and select database.
$link=mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");
          
     
// Get values from form 
$name=$_POST['name'];
$email=$_POST['email'];
$content=$_POST['content'];
$rating=$_POST['rating'];
$pid = $_SESSION['rpid'];
$product_id=(int)($pid);
     
//echo "$name :: $email :: $content :: $rating :: $product_id";
     
// Insert data into mysql 
$sql="INSERT INTO reviews VALUES(NULL,'$product_id','$content','$rating','$name','$email')";
     
$result=mysql_query($sql);
    
     //header("Location: item.php?id={$product_id}");
     mysql_close();
     
}

?> 


<br/>
    <!-- Page Content -->
<div class="container">

       <!-- Side Navigation -->
<div class="col-md-3">
              <?php include(TEMPLATE_FRONT . DS . "side_nav.php") ?>
</div>
<?php 

$query = query(" SELECT * FROM products WHERE product_id = " . escape_string($_GET['id']) . " ");
confirm($query);

while($row = fetch_array($query)):

 ?>


<div class="col-md-9">

<!--Row For Image and Short Description-->

<div class="row">

    <div class="col-md-7">


       <img class="img-responsive" height="1200" width="420" src="../resources/<?php  echo display_image($row['product_image']); ?>" alt="">


    </div>

    <div class="col-md-5">

        <div class="thumbnail">
         

    <div class="caption-full">
        <h4><a href="#"><?php echo $row['product_title']; ?></a> </h4>
        <hr>
        <h4 class=""><?php echo "&#36;" . $row['product_price']; ?></h4>

    <div class="ratings">
     
        <p>
            <?php $_SESSION['spid'] = $row['product_id']; ?>
            <?php include("rating.php") ?>
        </p>
    </div>
          
        <p><?php echo $row['short_desc']; ?></p>

   
    <form action="">
        <div class="form-group">
           <a href="../resources/cart.php?add=<?php echo $row['product_id']; ?>" class="btn btn-primary">ADD</a>
        </div>
    </form>

    </div>
 
</div>

</div>


</div><!--Row For Image and Short Description-->


<hr>


<!--Row for Tab Panel-->

<div class="row">

<div role="tabpanel">

  <!-- Nav tabs -->
  <ul class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Description</a></li>
    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Reviews</a></li>

  </ul>

  <!-- Tab panes -->
  <div class="tab-content">
    <div role="tabpanel" class="tab-pane active" id="home">

<p></p>

        

<p>
    <?php echo $row['product_description']; ?></p>
    </div>
    <div role="tabpanel" class="tab-pane" id="profile">
        
<div class="col-md-6">
       <h3> Reviews</h3>
    <hr>
<div id="" style="overflow:scroll; height:400px;">
    <?php $_SESSION['rpid'] = $row['product_id']; ?>
    <?php include("getReviews.php") ?>
</div> 
</div>

 <div class="col-md-6">
        <h3>Add A review</h3>
     <!-- <?php include("addreview.php") ?> -->
     
     <form id="reviewForm" action="" method="post" name="reviewForm" class="form-inline">
        
         <div class="form-group">
            <label for="">Name</label>
                <input type="text" name="name" class="form-control" required>
            </div>
             <div class="form-group">
            <label for="">Email</label>
                <input type="test" name="email" class="form-control" required>
            </div>
<hr>
        <div>
            <label for="">Rating</label>
      <select name="rating" class="form-control selectpicker" required>
      <option value="" >Rate Here</option>
      <option value="1">1 Star</option>
      <option value="2">2 Star</option>
      <option value="3">3 Star</option>
      <option value="4">4 Star</option>
      <option value="5">5 Star</option>
      </select>
            
        </div>

            <br>
            
             <div class="form-group">
             <textarea name="content" id="" cols="60" rows="10" class="form-control" required></textarea>
            </div>
            <div>
                <input type="hidden" name="product_id" value="<? echo "{$row['product_id']}"; ?>" />
         </div>
             <br>
              <br>
            <div class="form-group">
                <input type="submit" name="submit" class="btn btn-primary" value="SUBMIT">
            </div>
        </form>
     
 </div>

 </div>

</div>


</div><!--Row for Tab Panel-->

</div><!-- col-md-9 ends here -->
<?php endwhile; ?>

</div>
</div>
    <!-- /.container -->

<?php include(TEMPLATE_FRONT . DS . "footer.php") ?>