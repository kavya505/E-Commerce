<?php
    $connection = mysqli_connect('naivestuff.com.mysql','naivestuff_com','test123','naivestuff_com');
    if (mysqli_connect_errno())
    {
         echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
?>

<?php
if($_POST)
{
    $q = mysqli_real_escape_string($connection,$_POST['search']);
$strSQL_Result = mysqli_query($connection,"select product_id,product_title,product_price,product_image from products where product_title like '%$q%'LIMIT 5");
    
    if (!$strSQL_Result) {
    printf("Error: %s\n", mysqli_error($connection));
    exit();
}
    ?>
<?php
    while($row=mysqli_fetch_array($strSQL_Result))
    {
        $title   = $row['product_title'];
        $product_id=$row['product_id'];
        $product_image=$row['product_image'];
        $product_price=$row['product_price'];
        
        $b_title = '<strong>'.$q.'</strong>';
        $b_price   = '<strong>'.$q.'</strong>';
        $b_id='<strong>'.$q.'</strong>';
        $final_title = str_ireplace($q, $b_title, $title);
        $final_id = str_ireplace($q, $b_id, $product_id);
        $final_price = str_ireplace($q, $b_price, $product_price);
        
         echo " <a href='item.php?id={$product_id}''>
                <img src='../resources/uploads/$product_image' height=30 width=25>
                $final_title - &#36; $final_price
                </a> <hr/>";
        ?>
        <?php
    }
}
?>