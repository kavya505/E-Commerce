<html>    
    <head>  
                <link href="css/live-search.css" rel="stylesheet">
                <link href="css/expandSearch.css" rel="stylesheet">
               <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
               <script src=js/live-search.js type="text/javascript"></script>  
    </head>
     
        <form id="demo-2" class="navbar-form" name="searchForm" action="searchp.php" role="search" method="get">
            
          <div class="input-group">
           <input type="search" name="search" class="search" type="text" placeholder="Search the store here.." autocomplete="off">  
          </div>
          
           <div id="result" style="width: 300px;
                                    max-height: 300px;
                                    overflow-y: scroll;
                                    -webkit-overflow-scrolling: touch;">
           </div>
        </form>
</html>

