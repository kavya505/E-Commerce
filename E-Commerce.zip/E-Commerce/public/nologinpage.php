<?php require_once("../resources/config.php"); ?>

<!DOCTYPE html>
<html>
    <head>
        
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <title>Oliveiras Liqours</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
        <link href="agecheck.css" rel="stylesheet" />
        <script src="jquery.agecheck.min.js"></script>
                    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link href="css/round-about.css" rel="stylesheet">

    <!-- Age Verification CSS -->
    <link href="css/age-verification.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/shop-homepage.css" rel="stylesheet">

    <link href="css/styles.css" rel="stylesheet">

    <link href="css/ihover.css" rel="stylesheet">
    
    <link href="css/live-search.css" rel="stylesheet">
    
    <link href="css/font-awesome.css" rel="stylesheet">
    
<script type="text/javascript"
  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAXuX1hVaafKzgskA8mvcZGOttV0QGhdNo&libraries=geometry">
</script>
    <link href='http://fonts.googleapis.com/css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/style1.css"> <!-- Gem style -->
    <script src="js/modernizr.js"></script>
    <script src="js/live-search.js"></script>
    <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>  
    </head>
    
<body>
    <header>
        <h1><center>Log In First</center></h1>
    </header>
    <hr>
    <div class="container">
        <center>
        <h3>To acces the admin reports, You have to Login</h3>
        <h5><a href="http://naivestuff.com/public/admin_login.php" class="btn btn-success">Login Here</a></h5>
        </center>
    </div>
</body>