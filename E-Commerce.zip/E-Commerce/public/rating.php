<?php

$host="naivestuff.com.mysql"; // Host name 
$username="naivestuff_com"; // Mysql username 
$password="test123"; // Mysql password 
$db_name="naivestuff_com"; // Database name 
$tbl_name="reviews"; // Table name 

// Connect to server and select database.
$link=mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");


$spid = $_SESSION['spid'];
$product_id=(int)($spid);
   
// Insert data into mysql 
$sqlq="select avg(rating) as avgr from reviews where product_id=$product_id"; // where product_id=$product_id";

$rresult=mysql_query($sqlq);

$rrow = mysql_fetch_assoc($rresult);

    $avg=(float)$rrow['avgr'];
    $avg =(round($avg,1));

    if($avg==5){
      for($i=0;$i<=5;$i++)
    echo "<i class='fa fa-star'></i>";   
    }

    else if($avg>0 and $avg<0.5){
        echo "<i class='fa fa-star'></i>"; 
    }

    else if($avg>=0.5 and $avg<1){
        echo "<i class='fa fa-star-half'></i>";
    }

    else if($avg>=1 and $avg<1.5){
        for($i=0;$i<1;$i++)
        echo "<i class='fa fa-star'></i>"; 
    }

else if($avg>=1.5 and $avg<2){
    for($i=0;$i<1;$i++)
       echo "<i class='fa fa-star'></i>";  
        echo "<i class='fa fa-star-half'></i>";
    }

    else if($avg>=2 and $avg<2.5){
        for($i=0;$i<2;$i++)
        echo "<i class='fa fa-star'></i>"; 
    }

    else if($avg>=2.5 and $avg<3){
        for($i=0;$i<2;$i++)
        echo "<i class='fa fa-star'></i>"; 
        echo "<i class='fa fa-star-half'></i>";
    }

    else if($avg>=3 and $avg<3.5){
        for($i=0;$i<3;$i++)
        echo "<i class='fa fa-star'></i>"; 
    }

    else if($avg>=3.5 and $avg<4){
        for($i=0;$i<3;$i++)
        echo "<i class='fa fa-star'></i>";  
        echo "<i class='fa fa-star-half'></i>";
    }

    else if($avg>=4 and $avg<4.5){
        for($i=0;$i<4;$i++)
        echo "<i class='fa fa-star'></i>"; 
    }

    else if($avg>=4.5 and $avg<5){
        for($i=0;$i<4;$i++)
        echo "<i class='fa fa-star'></i>"; 
        echo "<i class='fa fa-star-half'></i>";
    }

    else {
        echo "Not Rated Yet.";
    }
     //header("Location: item.php?id={$product_id}");
     echo "<br>".$avg." stars";
    mysql_close();
     
?> 