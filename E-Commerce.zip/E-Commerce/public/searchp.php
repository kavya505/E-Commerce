<?php require_once("../resources/config.php"); ?>

<?php include(TEMPLATE_FRONT . DS . "header.php") ?>

<div style='font-size:20px;'>
    <hr>
    
<?php
$search = $_GET ['search']; 

    if( strlen( $search ) <= 1 ) 
        echo "Search term too short"; 
    else 
    { 
        echo "You searched for <b> '$search'  </b> <hr size='1' > </ br > 
    <h3>Search Results</h3>"; 
        
        mysql_connect( "naivestuff.com.mysql","naivestuff_com","test123") ; 
        mysql_select_db("naivestuff_com"); 
        $search_exploded = explode ( " ", $search ); 
        $x = 0; 
        foreach( $search_exploded as $search_each ) 
        { 
            $x++; 
            $construct = ""; 
            //if( $x == 1 ) 
                $construct .="product_title LIKE '%$search_each%'"; 
            //else 
               // $construct .="AND keywords LIKE '%$search_each%'"; 
        } 
        $construct = " SELECT * FROM products WHERE $construct "; 
        $run = mysql_query($construct ); 
        $foundnum = mysql_num_rows($run); 
        if ($foundnum == 0) 
            echo "Sorry, there are no matching result for <b> '$search' </b>."; 
        
        else { 
            echo "$foundnum results found ! 
                    <hr>   
                <div class='container'>
                <div class='row'>
                <div class='col-lg-2'></div>
                <div class='col-lg-10'> 
                <div class='row'>"; 
              while( $runrows = mysql_fetch_assoc( $run ) ) 
              { 
               $product_id = $runrows ['product_id']; 
               $product_title = $runrows ['product_title']; 
               $product_price = $runrows ['product_price']; 
               $product_image = $runrows['product_image'];
             
               
          echo "
          
    <div class='col-lg-4 col-md-4 col-sm-4 panel panel-default'  style:'height:350px;' >
    <div class = 'panel panel-default'>
    <div class = 'panel-heading'>
      <h3 class = 'panel-title'>
         {$product_title}
      </h3>
   </div></div>
    <div class='ih-item circle effect1 center-div'><a href='item.php?id={$product_id}'>
        <div class='spinner'></div>
        <div class='img'><img height='300' width='430' src='../resources/uploads/{$product_image}' alt='img'></div>
        <div class='info'>
          <div class='info-back'>
            <h3>{$product_title}</h3>
            <p>Price: &#36;{$product_price}</p>
          </div>
        </div></a>
        </div>
        Price: &#36;{$product_price}
        <p class='text-right'> <a class='btn btn-danger' href='../resources/cart.php?add={$product_id}'>Add to cart</a></p>
         </div>
         
         ";
              } 
             }  
        echo"</div></div>";
    }  
?>
</div>
<?php include(TEMPLATE_FRONT . DS . "footer.php") ?>