<?php require_once("../resources/config.php"); ?>

<?php include(TEMPLATE_FRONT . DS . "header.php") ?>

    <!-- Page Content -->
    <div class="container">

        <!-- Jumbotron Header -->
        <header>
            <center><h1>Shop</h1></center>
        </header>

        <hr>
        <center><h2>All Our Products</h2></center>
        <hr>
        <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-3">
        
            <?php include(TEMPLATE_FRONT . DS . "side_nav.php") ?>
        </div>
            
        <div class="col-lg-9 col-md-9 col-sm-9">
        <!-- /.row -->
        <!-- Page Features -->
        <div class="row text-center" >
                  <? if (isset($_GET["page"])) {
                    $page = $_GET["page"];
                    }

                    else {
                            $page=1;
                    }
                ?>
         <?php get_products_in_shop_page($page); ?>

        </div>
        <!-- /.row -->
        </div>
        </div>

    </div>
    <!-- /.container -->


<?php include(TEMPLATE_FRONT . DS . "footer.php") ?>
