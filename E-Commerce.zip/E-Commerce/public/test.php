<?php require_once("../resources/config.php"); ?>

<?php include(TEMPLATE_FRONT . DS . "header.php") ?>

    <div class="container">
        
         <h1>Checkout</h1>

    <table class="table table-striped table borderless">
        <thead>
          <tr>
           <th>Product</th>
           <th>Price</th>
           <th>Quantity</th>
           <th>Sub-total</th>
          </tr>
        </thead>
        <tbody>
          <?php cart(); ?>
        </tbody>
    </table>
<div class="row">
    
    <?include(TEMPLATE_FRONT . DS . "address.php")?>        
      
<div class="col-md-6" style="height: 474px;
                             padding: 19px;
                             margin-bottom: 20px;
                             background-color: #f5f5f5;
                             border: 1px solid #e3e3e3;
                             border-radius: 4px;
                            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .05);
                            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .05);">

<form action="thank_you.php" method="get">
    <h2>Cart Totals</h2>
    <hr><hr>
<br><br><br><br><br><br>
<table class="table table-bordered" cellspacing="0">

<tr class="cart-subtotal">
<th>Items:</th>
<td><span class="amount"><?php 
echo isset($_SESSION['item_quantity']) ? $_SESSION['item_quantity'] : $_SESSION['item_quantity'] = "0";?></span></td>
</tr>

<tr class="shipping">
<th>Estimated TAX</th>
<td><?php 
echo ($_SESSION['item_total'] * (9.5/100) );?></td>
</tr>

<tr class="order-total">
<th>Order Total</th>
<td><strong><span class="amount">&#36;<?php 
echo isset($_SESSION['item_total']) ? $_SESSION['item_total'] + ($_SESSION['item_total'] * (9.5/100) ) : $_SESSION['item_total'] = "0";?>
</span></strong> </td>
</tr>
</table>

<input type="hidden" name="order_amount" value= "<?php echo $_SESSION['item_total'] + ($_SESSION['item_total'] * (9.5/100) ) ; ?>" >
<input type="hidden" name="order_status" value="PENDING">
<input type="hidden" name="item_amount" value= "<?php echo $_SESSION['item_total']; ?>" >
<input type="hidden" name="order_tax" value= "<?php echo ($_SESSION['item_total'] * (9.5/100) ); ?>" >
<hr>

<?
if(add_address()!=1){     
    echo "<div class='alert alert-danger' role='alert'>
           <span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span>
           <span class='sr-only'>Error:</span>
           Enter Your Address
           </div>";
    }
    
if($_SESSION['item_total']==0)
    echo "<div class='alert alert-danger' role='alert'>
          <span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span>
          <span class='sr-only'>Error:</span>
          No items in the cart
          </div>";
?>
    
<?php echo show_place_order(); ?>
    
</div><!-- CART TOTALS-->

</form>
    
</div>
        
<?php include(TEMPLATE_FRONT . DS . "footer.php") ?>