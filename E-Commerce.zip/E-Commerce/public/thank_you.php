<?php require_once("../resources/config.php"); ?>
<?php include(TEMPLATE_FRONT . DS . "header.php") ?>


<?php process_transaction(); ?>
    <!-- Page Content -->
    <div class="container">

      <h1 class="text-center">THANK YOU</h1>
        <h2>Meet You At The Store.</h2>
          
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
      <div id="map-canvas"></div>
      </div>
    
      <div class="col-lg-4 col-md-4 col-sm-4">
     
          <address>
          <strong>Oiveiras</strong><br>
          <span id="map-input">
          1102 S Abel St.<br>
          Unit 306, CA 95035<br>
          </span>
          P: (123) 456-7890
         </address>
         <address>
          <strong>Email Us</strong><br>
          <a href="mailto:#">oliveiras@oliveiras.com</a>
         </address> 
     
        </div>
        
    </div>  
          
    </div>
    <!-- /.container -->

<?php include(TEMPLATE_FRONT . DS . "footer.php") ?>
