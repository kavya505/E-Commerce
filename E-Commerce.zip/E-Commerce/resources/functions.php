<?php 
$upload_directory = "uploads";

// helper functions
function last_id(){
global $connection;
return mysqli_insert_id($connection);
}

function set_message($msg){
if(!empty($msg)) {
$_SESSION['message'] = $msg;
} else {
$msg = "";
    }
}

function display_message() {
    if(isset($_SESSION['message'])) {
        echo $_SESSION['message'];
        unset($_SESSION['message']);
    }
}

function redirect($location){
return header("Location: $location");
}


function query($sql) {
global $connection;
return mysqli_query($connection, $sql);
}

function confirm($result){
global $connection;
if(!$result) {
die("QUERY FAILED " . mysqli_error($connection));
	}
}

function escape_string($string){
global $connection;
return mysqli_real_escape_string($connection, $string);
}

function fetch_array($result){
return mysqli_fetch_array($result);
}


function conDB(){
$host="naivestuff.com.mysql"; // Host name 
$username="naivestuff_com"; // Mysql username 
$password="test123"; // Mysql password 
$db_name="naivestuff_com"; // Database name 

// Connect to server and select database.
$link=mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");  
}
/****************************FRONT END FUNCTIONS************************/

// get products 
function get_products($page) {
conDB();
$per_page=9;
$start_from = ($page-1) * $per_page;
    
$query = query(" SELECT * FROM products LIMIT $start_from, $per_page");
confirm($query);

//Now select all from table
$squery = "select * from products";
$rresult=mysql_query($squery);
// Count the total records
$total_records = mysql_num_rows($rresult);
    
if(!($rresult)){
    die(mysql_error());
}

while($row = fetch_array($query)) {
$product_image = display_image($row['product_image']);
$product = <<<DELIMETER


    <div class="col-lg-4 col-md-4 col-sm-4 panel panel-default"  style:"height:350px;" >
    <div class = "panel panel-default">
    <div class = "panel-heading">
      <h3 class = "panel-title">
         {$row['product_title']}
      </h3>
   </div></div>
    <div class="ih-item circle effect1 center-div"><a href="item.php?id={$row['product_id']}">
        <div class="spinner"></div>
        <div class="img"><img src="../resources/{$product_image}" alt="img"></div>
        <div class="info">
          <div class="info-back">
            <h3>{$row['product_title']}</h3>
            <p>Price: &#36;{$row['product_price']}</p>
          </div>
        </div></a>
        </div>
        Price: &#36;{$row['product_price']}
        <p class='text-right'> <a class="btn btn-danger" href="../resources/cart.php?add={$row['product_id']}" >Add to cart</a></p>
         </div>

DELIMETER;
echo $product;
}

//Using ceil function to divide the total records on per page
$total_pages = ceil($total_records / $per_page);

//Going to first page
echo "</div><center>

<ul class='pagination'>
    <li>
      <a href='index.php?page=1' aria-label='First Page'>
        <span aria-hidden='true'>&laquo;</span>
      </a>
    </li> ";

for ($i=1; $i<=$total_pages; $i++) {
echo "<li><a href='index.php?page=$i'>$i</a></li>";
};

// Going to last page
echo "
<li>
      <a href='index.php?page=$total_pages'  aria-label='Last Page'>
        <span aria-hidden='true'>&raquo;</span>
      </a>
    </li>
</ul>
</center> ";
echo "</div><!-- Row ends here-->";
}
      
function get_categories(){        
$query = query("SELECT * FROM categories");
confirm($query);
while($row = fetch_array($query)) {
$categories_links = <<<DELIMETER
<a href='category.php?id={$row['cat_id']}' class='list-group-item'>{$row['cat_title']}</a>
DELIMETER;
echo $categories_links;
     }
}

function get_products_in_cat_page($page) {
conDB();
    
$per_page=6;
$start_from = ($page-1) * $per_page;
    
$query = query(" SELECT * FROM products WHERE product_category_id = " . escape_string($_GET['id']) ." LIMIT $start_from, $per_page");
confirm($query);
$squery = " SELECT * FROM products WHERE product_category_id = " . escape_string($_GET['id']) ." ";
$rresult=mysql_query($squery);
// Count the total records
$total_records = mysql_num_rows($rresult);
    
while($row = fetch_array($query)) {
$product_image = display_image($row['product_image']);
$product = <<<DELIMETER

    <div class="col-lg-4 col-md-4 col-sm-4 panel panel-default" >
    <div class = "panel panel-default">
    <div class = "panel-heading">
      <h3 class = "panel-title">
         {$row['product_title']}
      </h3>
   </div></div>
    <div class="ih-item circle effect1 center-div"><a href="item.php?id={$row['product_id']}">
        <div class="spinner"></div>
        <div class="img"><img src="../resources/{$product_image}" alt="img"></div>
        <div class="info">
          <div class="info-back">
            <h3>{$row['product_title']}</h3>
            <p>Price: &#36;{$row['product_price']}</p>
          </div>
        </div>
        </div></a>
        <p class='text-left'>Price: &#36;{$row['product_price']}</p>
        <p class='text-right'>
        <a class="btn btn-danger" href="../resources/cart.php?add={$row['product_id']}" >Add to cart</a></p>
         </div>

DELIMETER;
echo $product;
		}
//Using ceil function to divide the total records on per page
$total_pages = ceil($total_records / $per_page);
echo "</div><!-- col ends here-->";
//Going to first page
echo "</div><center>

<ul class='pagination'>
    <li>
      <a href='category.php?id={$_GET['id']}&page=1' aria-label='First Page'>
        <span aria-hidden='true'>&laquo;</span>
      </a>
    </li> ";

for ($i=1; $i<=$total_pages; $i++) {
echo "<li><a href='category.php?id={$_GET['id']}&page=$i'>$i</a></li>";
};

// Going to last page
echo "
<li>
      <a href='category.php?id={$_GET['id']}&page=$total_pages'  aria-label='Last Page'>
        <span aria-hidden='true'>&raquo;</span>
      </a>
    </li>
</ul>
</center> ";
echo "</div><!-- Row ends here-->";
}



function get_products_in_shop_page($page) {
conDB();
$per_page=9;
$start_from = ($page-1) * $per_page;
$query = query(" SELECT * FROM products LIMIT $start_from, $per_page");
confirm($query);

//Now select all from table
$squery = "select * from products";
$rresult=mysql_query($squery);
// Count the total records
$total_records = mysql_num_rows($rresult);
    
if(!($rresult)){
    die(mysql_error());
}    
    
while($row = fetch_array($query)) {
$product_image = display_image($row['product_image']);
$product = <<<DELIMETER

    <div class="col-lg-4 col-md-4 col-sm-4 panel panel-default" >
    <div class = "panel panel-default">
    <div class = "panel-heading">
      <h3 class = "panel-title">
         {$row['product_title']}
      </h3>
   </div></div>
    <div class="ih-item circle effect1 center-div"><a href="item.php?id={$row['product_id']}">
        <div class="spinner"></div>
        <div class="img"><img src="../resources/{$product_image}" alt="img"></div>
        <div class="info">
          <div class="info-back">
            <h3>{$row['product_title']}</h3>
            <p>Price: &#36;{$row['product_price']}</p>
          </div>
        </div>
        </div></a>
        <p class='text-left'>Price: &#36;{$row['product_price']}</p>
        <p class='text-right'>
        <a class="btn btn-danger" href="../resources/cart.php?add={$row['product_id']}" >Add to cart</a></p>
         </div>

DELIMETER;
echo $product;
        }
echo "</div><center>

<ul class='pagination'>
    <li>
      <a href='shop.php?page=1' aria-label='First Page'>
        <span aria-hidden='true'>&laquo;</span>
      </a>
    </li> ";
$total_pages = ceil($total_records / $per_page);
for ($i=1; $i<=$total_pages; $i++) {
echo "<li><a href='shop.php?page=$i'>$i</a></li>";
};

// Going to last page
echo "
<li>
      <a href='shop.php?page=$total_pages'  aria-label='Last Page'>
        <span aria-hidden='true'>&raquo;</span>
      </a>
    </li>
</ul>
</center> ";
echo "</div><!-- Row ends here-->";
}

function login_user(){
if(isset($_POST['submit'])){
$username = escape_string($_POST['email']);
$password = escape_string($_POST['password']);
$query = query("SELECT * FROM users WHERE email = '{$username}' AND password = '{$password }' ");
confirm($query);
if(mysqli_num_rows($query) == 0) {
echo  "<div class='alert alert-danger'>";
   echo "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
   echo "<strong>OOPS!</strong> The Userid or Password Incorrect <br> Please Try again </div>";
} else {
$_SESSION['username'] = $username;
$report = <<<DELIMETER
    <div class="alert alert-success">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Welcome </strong> $username.<br>
    <a href="admin">Admin page</a>
  </div>
DELIMETER;
echo $report;
         }
    }
}

function user_name() {
  if(isset($_SESSION['username'])){
  echo $_SESSION['username'];
}
}

function logout() {
  if(isset($_SESSION['username'])){
  
  $logout = <<<DELIMETER
    <a href="logout.php"><span class="glyphicon glyphicon-off"></span> Logout</a>
DELIMETER;
echo $logout;
}
}

function send_message() {
    if(isset($_POST['submit'])){ 
        $to          = "someEmailaddress@gmail.com";
        $from_name   =   $_POST['name'];
        $subject     =   $_POST['subject'];
        $email       =   $_POST['email'];
        $message     =   $_POST['message'];
        $headers = "From: {$from_name} {$email}";
        $result = mail($to, $subject, $message,$headers);
        if(!$result) {
            set_message("Sorry we could not send your message");
            redirect("contact.php");
        } else {
            set_message("Your Message has been sent");
            redirect("contact.php");
        }
    }
}

/****************************BACK END FUNCTIONS************************/

/****************************BACK END FUNCTIONS************************/

function display_orders(){
$query = query("SELECT * FROM orders");
confirm($query);
while($row = fetch_array($query)) {
$orders = <<<DELIMETER
<tr>
    <td><a>{$row['order_id']}</a></td>
    <td>&#36; {$row['order_amount']}</td>
    <td>{$row['order_status']}</td>
    <td>&#36; {$row['item_amount']}</td>
    <td>&#36; {$row['order_tax']}</td>
    <td><a class="btn btn-success" href="#">Completed</a></td>
    <td><a class="btn btn-danger" href="../../resources/templates/back/delete_order.php?id={$row['order_id']}"><span class="glyphicon glyphicon-trash"></span></a></td>
</tr>
</div>

DELIMETER;
echo $orders;
    }
}

function display_orders_products(){
$query = query("SELECT * FROM reports group by order_id");
confirm($query);
    
while($row = fetch_array($query)) {

$getPro = query("SELECT product_id,product_quantity FROM reports where order_id='{$row['order_id']}'");
confirm($getPro);

echo "
<h2>Order # : {$row['order_id']}</h2>
<p class='text-right'><h5>Order Time: {$row['order_date']}</h5></p>
  <table class='table table-condensed'>
    <thead>
      <tr>
        <th>Product Name</th>
        <th>Product Price</th>
        <th>Quantity</th>
      </tr>
    </thead>
    <tbody>
";
    echo "<p class='text-right'>
<a class='btn btn-danger' href='../../resources/templates/back/delete_report.php?id={$row['report_id']}'><span class='glyphicon glyphicon-trash'></span></a></p> ";
    
while($getrow = fetch_array($getPro)) {
$getProDet = query("SELECT * FROM products where product_id='{$getrow['product_id']}'");
confirm($getProDet);
$getrowDet = fetch_array($getProDet);    
    
$orders = <<<DELIMETER


    <tr>
        <td> {$getrowDet['product_title']} </td>
        <td> {$getrowDet['product_price']} </td>
        <td> {$getrow['product_quantity']} </td>
        <td></td>
    </tr>

<br>
</div>

DELIMETER;
echo $orders;
}
  echo "  </tbody>
</table> <hr> ";
    }
}


/************************ Admin Products Page ********************/
function display_image($picture) {
global $upload_directory;
return $upload_directory  . DS . $picture;
}

function get_products_in_admin(){
$query = query(" SELECT * FROM products");
confirm($query);
while($row = fetch_array($query)) {
$category = show_product_category_title($row['product_category_id']);
$product_image = display_image($row['product_image']);
$product = <<<DELIMETER
        <tr>
            <td>{$row['product_id']}</td>
            <td>{$row['product_title']}<br>
        <a href="index.php?edit_product&id={$row['product_id']}"><img width='100' src="../../resources/{$product_image}" alt=""></a>
            </td>
            <td>{$category}</td>
            <td>{$row['product_price']}</td>
            <td>{$row['product_quantity']}</td>
             <td><a class="btn btn-danger" href="../../resources/templates/back/delete_product.php?id={$row['product_id']}"><span class="glyphicon glyphicon-trash"></span></a></td>
        </tr>

DELIMETER;
echo $product;
        }
}

function get_messages_to_admin(){
$query = query(" SELECT * FROM inbox");
confirm($query);
while($row = fetch_array($query)) {
$message = <<<DELIMETER

        <div class="row">
            <div class="col-sm-4 col-md-4 col-lg-4"><h4><span class="label label-info">{$row['name']}</span></h4></div>
            <div class="col-sm-4 col-md-4 col-lg-4"><h4><span class="label label-info">{$row['email']}</span></h4></div>
            <div class="col-sm-4 col-md-4 col-lg-4"><h4><span class="label label-info">{$row['phone']}</span></h4></div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <p class="lead">{$row['message']}</p>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-4 col-md-4 col-lg-4"><h4></div>
            <div class="col-sm-4 col-md-4 col-lg-4"></div>
            <div class="col-sm-4 col-md-4 col-lg-4">
            <a class="btn btn-danger" href="../../resources/templates/back/delete_message.php?msg_id={$row['msg_id']}"><span class="glyphicon glyphicon-trash"></span></a>
            </div>
        </div>
            <hr>

DELIMETER;
echo $message;
        }
}

function show_product_category_title($product_category_id){
$category_query = query("SELECT * FROM categories WHERE cat_id = '{$product_category_id}' ");
confirm($category_query);
while($category_row = fetch_array($category_query)) {
return $category_row['cat_title'];
}
}

/***************************Add Products in admin********************/
function add_product() {
if(isset($_POST['publish'])) {
$product_title          = escape_string($_POST['product_title']);
$product_category_id    = escape_string($_POST['product_category_id']);
$product_price          = escape_string($_POST['product_price']);
$product_description    = escape_string($_POST['product_description']);
$short_desc             = escape_string($_POST['short_desc']);
$product_quantity       = escape_string($_POST['product_quantity']);
$product_image          = escape_string($_FILES['file']['name']);
$image_temp_location    = escape_string($_FILES['file']['tmp_name']);

move_uploaded_file($image_temp_location  , UPLOAD_DIRECTORY . DS . $product_image);

$query = query("INSERT INTO products(product_title, product_category_id, product_price, product_description, short_desc, product_quantity, product_image) VALUES('{$product_title}', '{$product_category_id}', '{$product_price}', '{$product_description}', '{$short_desc}', '{$product_quantity}', '{$product_image}')");
$last_id = last_id();
confirm($query);
set_message("New Product with id {$last_id} was Added");
redirect("index.php?products");
        }
}

function show_categories_add_product_page(){
$query = query("SELECT * FROM categories");
confirm($query);

while($row = fetch_array($query)) {
$categories_options = <<<DELIMETER
 <option value="{$row['cat_id']}">{$row['cat_title']}</option>
DELIMETER;
echo $categories_options;
     }
}

/***************************updating product code ***********************/

function update_product() {

if(isset($_POST['update'])) {

$product_title          = escape_string($_POST['product_title']);
$product_category_id    = escape_string($_POST['product_category_id']);
$product_price          = escape_string($_POST['product_price']);
$product_description    = escape_string($_POST['product_description']);
$short_desc             = escape_string($_POST['short_desc']);
$product_quantity       = escape_string($_POST['product_quantity']);
$product_image          = escape_string($_FILES['file']['name']);
$image_temp_location    = escape_string($_FILES['file']['tmp_name']);

if(empty($product_image)) {
$get_pic = query("SELECT product_image FROM products WHERE product_id =" .escape_string($_GET['id']). " ");
confirm($get_pic);
while($pic = fetch_array($get_pic)) {
$product_image = $pic['product_image'];
    }
}

move_uploaded_file($image_temp_location  , UPLOAD_DIRECTORY . DS . $product_image);

$query = "UPDATE products SET ";
$query .= "product_title            = '{$product_title}'        , ";
$query .= "product_category_id      = '{$product_category_id}'  , ";
$query .= "product_price            = '{$product_price}'        , ";
$query .= "product_description      = '{$product_description}'  , ";
$query .= "short_desc               = '{$short_desc}'           , ";
$query .= "product_quantity         = '{$product_quantity}'     , ";
$query .= "product_image            = '{$product_image}'          ";
$query .= "WHERE product_id=" . escape_string($_GET['id']);

$send_update_query = query($query);
confirm($send_update_query);
set_message("Product has been updated");
redirect("index.php?products");
        }
}

/*************************Categories in admin ********************/

function show_categories_in_admin() {
$category_query = query("SELECT * FROM categories");
confirm($category_query);

while($row = fetch_array($category_query)) {
$cat_id = $row['cat_id'];
$cat_title = $row['cat_title'];
$category = <<<DELIMETER
<tr>
    <td>{$cat_id}</td>
    <td>{$cat_title}</td>
    <td><a class="btn btn-danger" href="../../resources/templates/back/delete_category.php?id={$row['cat_id']}"><span class="glyphicon glyphicon-trash"></span></a></td>
</tr>
DELIMETER;
echo $category;
    }
}

function add_category() {
if(isset($_POST['add_category'])) {
$cat_title = escape_string($_POST['cat_title']);
if(empty($cat_title) || $cat_title == " ") {
echo "<p class='bg-danger'>THIS CANNOT BE EMPTY</p>";
} else {
$insert_cat = query("INSERT INTO categories(cat_title) VALUES('{$cat_title}') ");
confirm($insert_cat);
set_message("Category Created");
    }
    }
}

 /************************admin users***********************/

function display_users() {
$category_query = query("SELECT * FROM users");
confirm($category_query);

while($row = fetch_array($category_query)) {
$user_id = $row['user_id'];
$username = $row['username'];
$email = $row['email'];
$password = $row['password'];
$user = <<<DELIMETER
<tr>
    <td>{$user_id}</td>
    <td>{$username}</td>
     <td>{$email}</td>
    <td><a class="btn btn-danger" href="../../resources/templates/back/delete_user.php?id={$row['user_id']}"><span class="glyphicon glyphicon-trash"></span></a></td>
</tr>
DELIMETER;
echo $user;
    }
}

function add_user() {
if(isset($_POST['add_user'])) {
$username   = escape_string($_POST['username']);
$email      = escape_string($_POST['email']);
$password   = escape_string($_POST['password']);
// $user_photo = escape_string($_FILES['file']['name']);
// $photo_temp = escape_string($_FILES['file']['tmp_name']);
// move_uploaded_file($photo_temp, UPLOAD_DIRECTORY . DS . $user_photo);
$query = query("INSERT INTO users(username,email,password) VALUES('{$username}','{$email}','{$password}')");
confirm($query);
set_message("USER CREATED");
redirect("index.php?users");
}
}


function add_customer() {
if(isset($_POST['add_customer'])) {
$firstname   = escape_string($_POST['first_name']);
$lastname   = escape_string($_POST['last_name']);
$email      = escape_string($_POST['email']);
$password   = escape_string($_POST['password']);
// $user_photo = escape_string($_FILES['file']['name']);
// $photo_temp = escape_string($_FILES['file']['tmp_name']);
// move_uploaded_file($photo_temp, UPLOAD_DIRECTORY . DS . $user_photo);
$query = query("INSERT INTO customer(first_name,last_name,email,password,create_date) VALUES('{$firstname}','{$lastname}','{$email}','{$password}',NOW())");
confirm($query);
if(!$query) {
    echo "Please Try again..!";
}
else {
    $report = <<<DELIMETER
    <div class="alert alert-success">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success!</strong> Account Created.
  </div>
  
DELIMETER;
echo $report;
}
}
}

function add_address() {
$success=0;
if(isset($_POST['submit'])) {
$success=1;

$firstname   = escape_string($_POST['firstname']);
$lastname = escape_string($_POST['lastname']);
$email      = escape_string($_POST['email']);
$phone   = escape_string($_POST['phone']);
$address   = escape_string($_POST['address']);
$city = escape_string($_POST['city']);
$state = escape_string($_POST['state']);
$zip = escape_string($_POST['zip']);

$query1 = query("SELECT id FROM customer WHERE email = '{$email}' ");
confirm($query1);
$row = fetch_array($query1);
$customer_id = $row['id'];

$fullname=$firstname.' '.$lastname;

$query = query("INSERT INTO address(firstname,lastname,email,phone,address,city,state,zip) VALUES('{$customer_id}','{$fullname}','{$email}','{$phone}','{$address}','{$city}','{$state}','{$zip}')");

confirm($query);

if(!$query) {
    echo "Please Try again..!";
}
else {
    $report = <<<DELIMETER
    <div class="alert alert-success">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Address</strong> Successfully Saved.
  </div>
  
DELIMETER;
echo $report;
}
}
    return $success;
}

function login_customer(){
if(isset($_POST['submit'])){
$email = escape_string($_POST['email']);
$password = escape_string($_POST['password']);
$query = query("SELECT * FROM customer WHERE email = '{$email}' AND password = '{$password }' ");
$row = fetch_array($query);
confirm($query);
$email = $row['email'];

if(mysqli_num_rows($query) == 0) {

   echo  "<div class='alert alert-danger'>";
   echo "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
   echo "<strong>OOPS!</strong> The Userid or Password Incorrect </div>";
  
}
else {
$_SESSION['username'] = $row['email'];
$name = $_SESSION['username'];
$login_redirect = <<<DELIMETER
 <div class="alert alert-success">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Welcome </strong> $name <br>
    <a href="index.php">Enjoy Shopping..!</a>
  </div>
DELIMETER;
echo $login_redirect;
       }
    }
}

function get_reports(){
$query = query(" SELECT * FROM reports");
confirm($query);
while($row = fetch_array($query)) {
$report = <<<DELIMETER
        <tr>
             <td>{$row['report_id']}</td>
            <td>{$row['product_id']}</td>
            <td>{$row['order_id']}</td>
            <td>&#36; {$row['product_price']}</td>
            <td>{$row['product_title']}
            <td>{$row['product_quantity']}</td>
            <td><a class="btn btn-danger" href="../../resources/templates/back/delete_report.php?id={$row['report_id']}"><span class="glyphicon glyphicon-trash"></span></a></td>
        </tr>
DELIMETER;
echo $report;
        }
}

function add_reviews(){

 if (!empty($_POST['submit'])){
$host="naivestuff.com.mysql"; // Host name 
$username="naivestuff_com"; // Mysql username 
$password="test123"; // Mysql password 
$db_name="naivestuff_com"; // Database name 
$tbl_name="reviews"; // Table name 

// Connect to server and select database.
$link=mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");
     
$conn = new mysqli($host, $username, $password, $db_name);
     
     
// Get values from form 
$name=$_POST['name'];
$email=$_POST['email'];
$content=$_POST['content'];
$rating=$_POST['rating'];
session_start();
$pid = $_SESSION['rpid'];
$product_id=(int)($pid);
     
echo "$name :: $email :: $content :: $rating :: $product_id";
     
// Insert data into mysql 
$sql="INSERT INTO reviews VALUES(NULL,'$product_id','$content','$rating','$name','$email')";
     
$result=mysql_query($sql);
     
     if($result){
         echo "<h3><i class='label label-success'>Review Added Successfully</i></h3> ";
         echo "<BR>";
     }
    else{
             echo "<h3><i class='label label-danger'>Review did not  Delivered. sResult: $result</i></h3>";
             mysql_error($link); 
             echo "<BR>";
         }
     //header("Location: item.php?id={$product_id}");
     mysql_close();
     
}
}

?>