<?php require_once("../../config.php");


if(isset($_GET['msg_id'])) {


$query = query("DELETE FROM inbox WHERE msg_id = " . escape_string($_GET['msg_id']) . " ");
confirm($query);


set_message("Message deleted..");
redirect("../../../public/admin/index.php?inbox");
} else {

redirect("../../../public/admin/index.php?inbox");
}

 ?>