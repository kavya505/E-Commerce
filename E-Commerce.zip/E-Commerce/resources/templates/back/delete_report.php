<?php require_once("../../config.php");


if(isset($_GET['id'])) {


$query = query("DELETE FROM reports WHERE report_id = " . escape_string($_GET['id']) . " ");
confirm($query);


set_message("Report Deleted");
$url='../../../public/admin/index.php?orders';
echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';


} else {
set_message("Erro: Report cant be Deleted");
$url='../../../public/admin/index.php?orders';
echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';

}






 ?>