
<h1 class="page-header">
   Inbox
</h1>

<h3 class="bg-success"><?php display_message(); ?></h3>

<div class="container">      
      <?php get_messages_to_admin(); ?>

</div>