  <!-- Footer -->
        <footer style="background-color: lightgrey">
<div class="footer-blurb">
<div class="container">
<div class="row">
  <div class="col-md-4">
  <h4 class=page-header>Navigate Here</h4>
                        <ul>
							<li><a href="#">Home</a></li>
							<li><a href="shop.php">Shop</a></li>
                            <li><a href="contact.php">Contact</a></li>
						</ul>
      
  </div>
  <div class="col-md-4">
  
      <h4 class=page-header>Our Products</h4>
                        <ul>
							<li><a href="category.php?id=34">Wines</a></li>
							<li><a href="category.php?id=35">Liquors</a></li>
							<li><a href="category.php?id=36">Beers</a></li>
						</ul>
      
  </div>
      
  <div class="col-md-4">
  
      <h4 class="page-header">Oliveiras Liquors</h4>

      1948 S Foresthill Pl, Danville, CA 94526 <br>                                     
      <span class="glyphicon glyphicon-earphone"></span> +1 XXX XXX XXXX <br>
      <span class="glyphicon glyphicon-envelope"></span> subhash@oliveiras.com <br>
      <span class="glyphicon glyphicon-envelope"></span> bramha@oliveiras.com

      
  </div>
</div>
       
<div class="row">
    <div class="col-md-4">
        <div class="small-print">
        	<div class="container">
                <small><a href="#">Terms &amp; Conditions</a> | <a href="#">Privacy Policy</a> | Copyright &copy; Oliveiras Liquors 2016
                </small>
        	</div>
        </div>
    </div>
</div>

</div>
</div>
</footer>


    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <script src="js/script.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <script src="js/jquery.js"></script>

    <!-- Plugin JavaScript -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    
    <script src="js/classie.js"></script>
    <script src="js/cbpAnimatedHeader.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>
    
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="js/main.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/agency.js"></script>

</body>

</html>
