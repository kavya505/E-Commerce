<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <title>Oliveiras Liqours</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link href="css/round-about.css" rel="stylesheet">

    <!-- Age Verification CSS -->
    <link href="css/age-verification.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/shop-homepage.css" rel="stylesheet">

    <link href="css/styles.css" rel="stylesheet">

    <link href="css/ihover.css" rel="stylesheet">
    
    <link href="css/live-search.css" rel="stylesheet">
    
    <link href="css/font-awesome.css" rel="stylesheet">
    
<script type="text/javascript"
  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAXuX1hVaafKzgskA8mvcZGOttV0QGhdNo&libraries=geometry">
</script>
    
    <script lang="text/javasrcipt">
            function initialize() {           
            var mapOptions = {
                center: new google.maps.LatLng(37.4142289,-121.9058979),
                zoom: 15,
                mapTypeId: google.maps.MapTypeId.HYBRID,
                scrollwheel: false,
                draggable: false,
                panControl: true,
                zoomControl: true,
                mapTypeControl: true,
                scaleControl: true,
                streetViewControl: true,
                overviewMapControl: true,
                rotateControl: true,
            };
            var map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);
              marker = new google.maps.Marker({
              map: map,
              draggable: true,
              animation: google.maps.Animation.DROP,
              position: new google.maps.LatLng(37.4142289,-121.9058979)
  });
  marker.addListener('click', toggleBounce);
}
        function toggleBounce() {
  if (marker.getAnimation() !== null) {
    marker.setAnimation(null);
  } else {
    marker.setAnimation(google.maps.Animation.BOUNCE);
  }
}
        
google.maps.event.addDomListener(window, 'load', initialize);
</script>

<style>
#map-canvas {
  width: 100%;
  height: 400px;
  margin-bottom: 15px;
  border: 2px solid #fff;
}
</style>
    
  <!-- to shrink nav bar-->  
    <style>
nav.navbar.shrink {
  min-height: 35px;
}

nav.shrink a {
  padding-top: 10px !important;
  padding-bottom: 10px !important;
  font-size: 15px;
}

nav.shrink .navbar-brand {
  font-size: 25px;
}

nav.shrink .navbar-toggle {
  padding: 4px 5px;
  margin: 8px 15px 8px 0;
}
.shrinkb {
  padding: 4px 5px;
  margin: 8px 15px 8px 0;
}
        
    </style>

    <link href='http://fonts.googleapis.com/css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>

    <link rel="stylesheet" href="css/style1.css"> <!-- Gem style -->
    
    <script src="js/modernizr.js"></script>
    <script src="js/live-search.js"></script>
    <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>    

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-fixed-top navbar-inverse" role="navigation">
      <?php include(TEMPLATE_FRONT . DS . "top_nav.php") ?>
    </nav>

    
<!-- Slider -->

