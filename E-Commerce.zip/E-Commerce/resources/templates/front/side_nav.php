

    <p class="lead">Categories</p>
    
    <div class="list-group">
    	<?php 
    		get_categories();
    	 ?>
    </div>

