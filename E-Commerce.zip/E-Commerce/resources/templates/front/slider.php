<!-- Carousel
================================================== -->
<div id="myCarousel" class="carousel slide">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="item active">
      <img src="../resources/uploads/slider_1.jpg" style="width:100%" class="img-responsive">
      <div class="container">
        <div class="carousel-caption">
          <h1>Top Quality Products</h1>
          <p></p>
          <p><a class="btn btn-lg btn-primary" href="shop.php">Shop</a>
        </p>
        </div>
      </div>
    </div>
    <div class="item">
      <img src="../resources/uploads/slider_2.jpg" class="img-responsive">
      <div class="container">
        <div class="carousel-caption">
          <h1>Choose Your Perfect Wine</h1>
          <p></p>
          <p><a class="btn btn-large btn-primary" href="category.php?id=34">Shop Wine Here</a></p>
        </div>
      </div>
    </div>
    <div class="item">
      <img src="../resources/uploads/slider_3.jpg" class="img-responsive">
      <div class="container">
        <div class="carousel-caption">
          <h1>100% Satisfaction Guaranteed</h1>
          <p></p>
          <p><a class="btn btn-large btn-primary" href="category.php?id=36">Shop Beer Here</a></p>
        </div>
      </div>
    </div>
  </div>
  <!-- Controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="icon-prev"></span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="icon-next"></span>
  </a>  
</div>
<!-- /.carousel -->
