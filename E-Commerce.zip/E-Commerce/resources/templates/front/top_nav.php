
    <div class = "container">
        <div class="navbar-header">
            <button class = "navbar-toggle pull-left" data-toggle = "collapse" data-target = "#nav-header-links-collapse">
                <span class = "icon-bar"></span>
                <span class = "icon-bar"></span>
                <span class = "icon-bar"></span>
            </button>
            <a class="navbar-brand navbar-brand-centered" href="#" data-toggle = "collapse" data-target = "#nav-header-logo-collapse">
                <img alt="logo" width="80" height="30" src="logo.png">
            </a>
            <a href="#" class = "navbar-toggle pull-right glyphicon glyphicon-search" data-toggle = "collapse" data-target = "#nav-header-search-collapse"></a>
        </div>   
        
            <div class = "nav navbar-nav collapse navbar-collapse" id="nav-header-search-collapse">
                    <?php include('lsearch.php') ?>
            </div>
        
         
               <!-- Slide Out -->
    <div id="cd-shadow-layer"></div>
<!-- cd-cart -->
    <div id="cd-cart">
        <h3>Cart</h3>

        <table class="table table-striped">
        <thead>
          <tr>
           <th>Product</th>
           <th>Price</th>
           <th>Quantity</th>
           <th>Sub-total</th>
          </tr>
        </thead>
        <tbody>
          <?php cart(); ?>
        </tbody>
    </table>

        <div class="cd-cart-total">
            <p>Total <span>&#36;<?php 
echo isset($_SESSION['item_total']) ? $_SESSION['item_total'] : $_SESSION['item_total'] = "0";?></span></p>
        </div>  <!-- cd-cart-total -->

        <a href="checkout.php" class="checkout-btn">Checkout</a>
        
        <p class="cd-go-to-cart"> </p>
    </div> <!-- cd-cart -->   
        

            <div class = "collapse navbar-collapse nav navbar-nav navbar-left" id="nav-header-links-collapse">
                    <ul class = "nav navbar-nav navbar-left">
                    <li> <a href="index.php">Home</a> </li>
                    <li> <a href="shop.php">Shop</a>  </li>
                    <li>  <a href="login.php">Login</a> </li>
                    <li> <a href="checkout.php">Checkout</a> </li>
                    <li> <a href="contact.php">Contact</a> </li>
                    <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-user"></span> My Account <span class="caret"></span></a>
                <ul class="dropdown-menu">
                <li><?php user_name(); ?></li>
                <li role="separator" class="divider"></li>
                <li><a href="checkout.php">Check-Out</a></li>
                <li role="separator" class="divider"></li>
                <li><a href="login.php">Login</a></li>
                <li role="separator" class="divider"></li>
                <li><a href="registration.php">Register</a></li>
                <li role="separator" class="divider"></li>
                <li><?php logout(); ?></li>
                </ul>
                    </li>
                        <li>
                        <a href="#">
                            <div id="cd-cart-trigger"><span class="glyphicon glyphicon-shopping-cart"></span>Cart(<?php echo isset($_SESSION['item_quantity']) ? $_SESSION['item_quantity'] : $_SESSION['item_quantity'] = "0";?>)</div>
                        </a>
                        </li>
                    </ul>
            </div>
              
</div>


